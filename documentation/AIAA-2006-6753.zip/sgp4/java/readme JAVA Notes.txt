SGP4 JAVA Version Notes

I have two versions of JAVA out here. The JAVA version just isn't verified yet - I just haven't had time to actually get a good test program up and running to
independantly test and verify the routine. The goal is to run the test cases in sgp4-test.tle and make sure all the answers are the same as in the other languages. 

Once I get a consolidated test program and verify them, I'll get a consolidated version out there. 

 